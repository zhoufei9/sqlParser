package com.gosun.mmtrix.sqlParser.util;

import java.util.Random;

public class RandomUtil {
	
	public static int getRandom(int min, int max){
		Random random = new Random();
	    int result = random.nextInt(max) % (max - min + 1) + min;
	    return result;
	}
	
	public static int getRandomByString(String str){
		
		String[] strArr = str.split(",");
		int max = Integer.valueOf(strArr[1]);
		int min = Integer.valueOf(strArr[0]);
		
		Random random = new Random();
	    int result = random.nextInt(max) % (max - min + 1) + min;
	    return result;
		
	}
	
	public static void main(String[] args) {
		int result = getRandom(1, 2);
		System.out.println(result);
		System.out.println("===================");
		System.out.println(getRandomByString("0,10000"));
	}
	


}
