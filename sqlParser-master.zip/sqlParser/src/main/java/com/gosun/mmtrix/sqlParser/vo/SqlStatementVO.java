package com.gosun.mmtrix.sqlParser.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class SqlStatementVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 数据库类型
	 */
	private String databaseType;
	/**
	 * 操作类型
	 */
	private String operateType;
	/**
	 * insert操作  column对应value的map
	 */
	private Map<String,Object> insertItemsMap;
	/**
	 * 表名
	 */
	private String tableName;
	/**
	 * update操作  column对应value的map
	 */
	private Map<String,Object> updateItemsMap;
	/**
	 * where条件
	 */
	private List<WhereConditionVO> whereCondition;
	/**
	 * 数据库名称
	 */
	private String databaseName;
	
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	public String getDatabaseType() {
		return databaseType;
	}
	public void setDatabaseType(String databaseType) {
		this.databaseType = databaseType;
	}
	public String getOperateType() {
		return operateType;
	}
	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}
	public Map<String, Object> getInsertItemsMap() {
		return insertItemsMap;
	}
	public void setInsertItemsMap(Map<String, Object> insertItemsMap) {
		this.insertItemsMap = insertItemsMap;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public Map<String, Object> getUpdateItemsMap() {
		return updateItemsMap;
	}
	public void setUpdateItemsMap(Map<String, Object> updateItemsMap) {
		this.updateItemsMap = updateItemsMap;
	}
	public List<WhereConditionVO> getWhereCondition() {
		return whereCondition;
	}
	public void setWhereCondition(List<WhereConditionVO> whereCondition) {
		this.whereCondition = whereCondition;
	}
	
	
	

	
	
	
	
	
	
	
	
	

}
