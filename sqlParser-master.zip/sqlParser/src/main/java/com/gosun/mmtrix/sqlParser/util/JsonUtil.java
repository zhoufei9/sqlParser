package com.gosun.mmtrix.sqlParser.util;



import java.io.IOException;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author he_jiebing
 * Json工具类
 *
 */
public class JsonUtil {
	
	
	/**
	 * 对象转Json字符串(包括list集合转Json字符串)
	 * @param object
	 * @return
	 * @throws Exception
	 */
	public static String object2JsonString(Object object){
		if (null != object) {
			 ObjectMapper mapper = new ObjectMapper();  
		     try {
				return mapper.writeValueAsString(object);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		return "";
	}
	/**
	 * Json字符串转为对象
	 * @param jsonString
	 * @param objectClass
	 * @return
	 * @throws Exception
	 */
	public static <T> T jsonString2Object(String jsonString,Class<T> objectClass){
		if(StringUtils.isNotBlank(jsonString)){
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				return objectMapper.readValue(jsonString, objectClass);
			} catch (JsonParseException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	/**
	 * Json数组字符串转List
	 * @param jsonArrayString
	 * @param valueTypeRef
	 * @return
	 * @throws Exception
	 */
	public static <T> T jsonArrayString2List(String jsonArrayString,TypeReference<T> valueTypeRef){
		if(StringUtils.isNotBlank(jsonArrayString)){
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				return objectMapper.readValue(jsonArrayString, valueTypeRef);
			} catch (JsonParseException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	

}
