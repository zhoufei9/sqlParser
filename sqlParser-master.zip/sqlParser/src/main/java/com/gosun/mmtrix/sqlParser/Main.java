package com.gosun.mmtrix.sqlParser;

import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;

import com.gosun.mmtrix.sqlParser.constants.Const;
import com.gosun.mmtrix.sqlParser.util.JsonUtil;
import com.gosun.mmtrix.sqlParser.util.SqlParserUtil;
import com.gosun.mmtrix.sqlParser.vo.JsonResult;

public class Main {

	public static void main(String[] args) {
		JsonResult jsonResult = new JsonResult();
		if (args.length >= 2) {
			String sql = "";
			String dbType = "";
			if (StringUtils.isNotBlank(args[0])) {
				dbType = args[0];
			}
			if (StringUtils.isNotBlank(args[1])) {
				sql = args[1];
			}
			try {
 				jsonResult = SqlParserUtil.parseSqlParser(dbType, sql);
			} catch (Exception e) {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_UNKNOW_ERROR_MSG+e);
			}
		} else {
			jsonResult.setCode(Const.ERROR_CODE);
			jsonResult.setResult("");
			jsonResult.setMsg(Const.EXCEPTION_ILLEAGL_ARGS_MSG+Arrays.asList(args));
		}
		System.out.println(JsonUtil.object2JsonString(jsonResult));
		//testExport();
		//testSelect();
		//testMysqlUpdate();
	}
	
	public static void testSelect(){
		JsonResult jsonResult = new JsonResult();
		//String sql = "select * from TEST.EMPLOEE where id=00001;";
		//String sql = "select count(*) from TEST.EMPLOEE where id in (00001,00002,00003,00004);";
		String sql = "select ID,XM,DEPT,TITLE,STATS,MOBNUM,EMAIL from TEST.EMPLOEE where id in(00001,00002,00003,00004);";
		
		
		String databaseType = "mysql";
		jsonResult = SqlParserUtil.parseSqlParser(databaseType, sql);
		System.out.println(JsonUtil.object2JsonString(jsonResult));
	}
	
	public static void testExport(){
		
		JsonResult jsonResult = new JsonResult();
		//String sql = "select * from TEST.EMPLOEE where id=00001;";
		//String sql = "select count(*) from TEST.EMPLOEE where id in (00001,00002,00003,00004);";
		String sql = "export to TEST.EMPLOEE.ixf of ixf select * from TEST.EMPLOEE where id=00001;";
		
		
		String databaseType = "db2";
		jsonResult = SqlParserUtil.parseSqlParser(databaseType, sql);
		System.out.println(JsonUtil.object2JsonString(jsonResult));
		
	}
	
	public static void testMysqlUpdate(){
		JsonResult jsonResult = new JsonResult();
		//String sql = "update host set visible_name = 'abc' where id = 3";
		String sql = "update tbl_person t set (name,age,email) = ('mmtrix','25','764182087@qq.com') where id = '1001' and sex = 'M'";
		
		//String sql = "update tbl_person t set name = 'mmtrix',age = 25 ,email = '764182087@qq.com' where id = '1001' and sex = 'M'";

		//String sql = "update tbl_person t set name = 'mmtrix',age = 25 where id = '1001';";
		String databaseType = "mysql";
		jsonResult = SqlParserUtil.parseSqlParser(databaseType, sql);
		System.out.println(JsonUtil.object2JsonString(jsonResult));
	}

}
