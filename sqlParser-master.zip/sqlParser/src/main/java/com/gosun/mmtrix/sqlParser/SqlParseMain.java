package com.gosun.mmtrix.sqlParser;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.gosun.mmtrix.sqlParser.constants.Const;
import com.gosun.mmtrix.sqlParser.util.JsonUtil;
import com.gosun.mmtrix.sqlParser.util.SqlParserUtil;
import com.gosun.mmtrix.sqlParser.vo.JsonResult;
import com.gosun.mmtrix.sqlParser.vo.ParamInfo;



public class SqlParseMain {
	
	public static void main(String[] args) {
		//long startTime = System.currentTimeMillis();
		List<JsonResult> resultList = new ArrayList<JsonResult>();
		if(args.length==1){
			
			if(StringUtils.isNotBlank(args[0])){
				String paramJson = args[0];
				//System.out.println(paramJson);
				ParamInfo paramInfo = new ParamInfo();
				try {
					paramInfo = JsonUtil.jsonString2Object(paramJson,ParamInfo.class);
				} catch (Exception e) {
					//e.printStackTrace();
					
				}
				
				String dbType = paramInfo.getDbType();
				
				List<String> sqlList = paramInfo.getSqlList();
				for (String sql : sqlList) {
					JsonResult jsonResult = new JsonResult();
					try {
		 				jsonResult = SqlParserUtil.parseSqlParser(dbType, sql);
		 				resultList.add(jsonResult);
					} catch (Exception e) {
						jsonResult.setCode(Const.ERROR_CODE);
						jsonResult.setResult("");
						jsonResult.setMsg(Const.EXCEPTION_UNKNOW_ERROR_MSG+e);
					}
				}
			}
			
			
		}
		//long endTime = System.currentTimeMillis();
		//System.out.println("耗时:"+(endTime-startTime)/1000.0+"秒");
		System.out.println(JsonUtil.object2JsonString(resultList));
		
	}

}
