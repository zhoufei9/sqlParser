package com.gosun.mmtrix.sqlParser.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.druid.sql.SQLUtils;
import com.alibaba.druid.sql.ast.SQLExpr;
import com.alibaba.druid.sql.ast.SQLStatement;
import com.alibaba.druid.sql.ast.expr.SQLBetweenExpr;
import com.alibaba.druid.sql.ast.expr.SQLBinaryOpExpr;
import com.alibaba.druid.sql.ast.expr.SQLCharExpr;
import com.alibaba.druid.sql.ast.expr.SQLIdentifierExpr;
import com.alibaba.druid.sql.ast.expr.SQLInListExpr;
import com.alibaba.druid.sql.ast.expr.SQLListExpr;
import com.alibaba.druid.sql.ast.expr.SQLPropertyExpr;
import com.alibaba.druid.sql.ast.statement.SQLDeleteStatement;
import com.alibaba.druid.sql.ast.statement.SQLExprTableSource;
import com.alibaba.druid.sql.ast.statement.SQLInsertStatement;
import com.alibaba.druid.sql.ast.statement.SQLInsertStatement.ValuesClause;
import com.alibaba.druid.sql.ast.statement.SQLSelectStatement;
import com.alibaba.druid.sql.ast.statement.SQLUpdateSetItem;
import com.alibaba.druid.sql.ast.statement.SQLUpdateStatement;
import com.alibaba.druid.sql.dialect.db2.visitor.DB2SchemaStatVisitor;
import com.alibaba.druid.sql.dialect.mysql.ast.statement.MySqlDeleteStatement;
import com.alibaba.druid.sql.dialect.mysql.ast.statement.MySqlInsertStatement;
import com.alibaba.druid.sql.dialect.mysql.ast.statement.MySqlUpdateStatement;
import com.alibaba.druid.sql.dialect.mysql.visitor.MySqlSchemaStatVisitor;
import com.alibaba.druid.sql.dialect.oracle.ast.stmt.OracleDeleteStatement;
import com.alibaba.druid.sql.dialect.oracle.ast.stmt.OracleInsertStatement;
import com.alibaba.druid.sql.dialect.oracle.ast.stmt.OracleUpdateStatement;
import com.alibaba.druid.sql.dialect.oracle.visitor.OracleSchemaStatVisitor;
import com.alibaba.druid.stat.TableStat;
import com.alibaba.druid.stat.TableStat.Name;
import com.gosun.mmtrix.sqlParser.constants.Const;
import com.gosun.mmtrix.sqlParser.vo.JsonResult;
import com.gosun.mmtrix.sqlParser.vo.SqlStatementVO;
import com.gosun.mmtrix.sqlParser.vo.WhereConditionVO;

public class SqlParserUtil {


	public static JsonResult parseSqlParser(String databaseType,String sql) {
		JsonResult jsonResult = new JsonResult();
		Map<String, Object> insertItemsMap = new HashMap<String, Object>();
		String tableName = new String();
		String operateType = "";
		List<WhereConditionVO> whereCondition = new ArrayList<WhereConditionVO>();
		Map<String, Object> updateItemsMap = new HashMap<String, Object>();
		SqlStatementVO statementVO = new SqlStatementVO();
		if (Const.DB_MYSQL.equals(databaseType)) {
			List<SQLStatement> stmtList = new ArrayList<SQLStatement>();
			try {
				stmtList = SQLUtils.parseStatements(sql, databaseType);
			} catch (Exception e) {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_SQL_MSG+"sql["+sql+"],message["+e.getMessage()+"]");
				return jsonResult;
			}
			SQLStatement stmt = stmtList.get(0);
			MySqlSchemaStatVisitor visitor = new MySqlSchemaStatVisitor();
			stmt.accept(visitor);
			Map<Name, TableStat> map = visitor.getTables();
			for (Map.Entry<Name, TableStat> entry : map.entrySet()) {
				operateType = entry.getValue().toString().toLowerCase();
			}
			if (Const.OPR_INSERT.equals(operateType.toUpperCase())) {
				MySqlInsertStatement insertStatement = (MySqlInsertStatement) stmtList.get(0);
				statementVO = parseInsertStatement(insertStatement);
				
			} else if (Const.OPR_UPDATE.equals(operateType.toUpperCase())) {
				MySqlUpdateStatement updateStatement = (MySqlUpdateStatement) stmtList.get(0);
				updateStatement.setDbType(databaseType);
				statementVO = parseUpdateStatement(updateStatement);
				
			} else if (Const.OPR_DELETE.equals(operateType.toUpperCase())) {
				MySqlDeleteStatement deleteStatement = (MySqlDeleteStatement) stmtList.get(0);
				statementVO = parseDeleteStatement(deleteStatement);

			} else if (Const.OPR_SELECT.equals(operateType.toUpperCase())) {
				SQLSelectStatement selectStatement = (SQLSelectStatement) stmtList.get(0);
				statementVO = parseSelectStatement(selectStatement);
			} else {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_SQL_MSG+sql);
				return jsonResult;
			}
		} else if (Const.DB_ORACLE.equals(databaseType)) {
			List<SQLStatement> stmtList = new ArrayList<SQLStatement>();
			try {
				stmtList = SQLUtils.parseStatements(sql, databaseType);
			} catch (Exception e) {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_SQL_MSG+"sql["+sql+"],message["+e.getMessage()+"]");
				return jsonResult;
			}
			SQLStatement stmt = stmtList.get(0);
			OracleSchemaStatVisitor visitor = new OracleSchemaStatVisitor();
			stmt.accept(visitor);
			Map<Name, TableStat> map = visitor.getTables();
			for (Map.Entry<Name, TableStat> entry : map.entrySet()) {
				operateType = entry.getValue().toString().toLowerCase();
			}
			if (Const.OPR_INSERT.equals(operateType.toUpperCase())) {
				OracleInsertStatement insertStatement = (OracleInsertStatement) stmtList.get(0);
				statementVO = parseInsertStatement(insertStatement);
			} else if (Const.OPR_UPDATE.equals(operateType.toUpperCase())) {
				OracleUpdateStatement updateStatement = (OracleUpdateStatement) stmtList.get(0);
				statementVO = parseUpdateStatement(updateStatement);
			} else if (Const.OPR_DELETE.equals(operateType.toUpperCase())) {
				OracleDeleteStatement deleteStatement = (OracleDeleteStatement) stmtList.get(0);
				statementVO = parseDeleteStatement(deleteStatement);

			}else if (Const.OPR_SELECT.equals(operateType.toUpperCase())) {
				SQLSelectStatement selectStatement = (SQLSelectStatement) stmtList.get(0);
				statementVO = parseSelectStatement(selectStatement);

			} else {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_SQL_MSG+sql);
				return jsonResult;
			}

		} else if (Const.DB_DB2.equals(databaseType)) {
			List<SQLStatement> stmtList = new ArrayList<SQLStatement>();
			
			if(sql.toUpperCase().startsWith("EXPORT")){
				jsonResult.setCode(0);
				jsonResult.setResult("success");
				jsonResult.setMsg("success");
				return jsonResult;
			}
			try {
				stmtList = SQLUtils.parseStatements(sql, databaseType);
			} catch (Exception e) {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_SQL_MSG+"sql["+sql+"],message["+e.getMessage()+"]");
				return jsonResult;
			}
			SQLStatement stmt = stmtList.get(0);
			DB2SchemaStatVisitor visitor = new DB2SchemaStatVisitor();
			stmt.accept(visitor);
			Map<Name, TableStat> map = visitor.getTables();
			for (Map.Entry<Name, TableStat> entry : map.entrySet()) {
				operateType = entry.getValue().toString().toLowerCase();
			}
			if (Const.OPR_INSERT.equals(operateType.toUpperCase())) {
				SQLInsertStatement insertStatement = (SQLInsertStatement) stmtList.get(0);
				statementVO = parseInsertStatement(insertStatement);
			} else if (Const.OPR_UPDATE.equals(operateType.toUpperCase())) {
				SQLUpdateStatement updateStatement = (SQLUpdateStatement) stmtList.get(0);
				updateStatement.setDbType(databaseType);
				statementVO = parseUpdateStatement(updateStatement);
			} else if (Const.OPR_DELETE.equals(operateType.toUpperCase())) {
				SQLDeleteStatement deleteStatement = (SQLDeleteStatement) stmtList.get(0);
				statementVO = parseDeleteStatement(deleteStatement);
			}else if (Const.OPR_SELECT.equals(operateType.toUpperCase())) {
				SQLSelectStatement selectStatement = (SQLSelectStatement) stmtList.get(0);
				statementVO = parseSelectStatement(selectStatement);

			} else {
				jsonResult.setCode(Const.ERROR_CODE);
				jsonResult.setResult("");
				jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_SQL_MSG+sql);
				return jsonResult;
			}

		}else{
			jsonResult.setCode(Const.ERROR_CODE);
			jsonResult.setResult("");
			jsonResult.setMsg(Const.EXCEPTION_ILLEGAL_DATABASETYPE_MSG+databaseType);
			return jsonResult;
		}
		if(statementVO.getInsertItemsMap()==null){
			statementVO.setInsertItemsMap(insertItemsMap);
		}
		
		if(StringUtils.isBlank(statementVO.getTableName())){
			statementVO.setTableName(tableName);
		}
		
		if(statementVO.getUpdateItemsMap()==null){
			statementVO.setUpdateItemsMap(updateItemsMap);
		}
		if(statementVO.getWhereCondition()==null){
			statementVO.setWhereCondition(whereCondition);
		}
		statementVO.setDatabaseType(databaseType);
		statementVO.setOperateType(operateType);
		jsonResult.setCode(Const.SUCCESS_CODE);
		jsonResult.setResult(statementVO);
		jsonResult.setMsg("");
		return jsonResult;
	}
	private static SqlStatementVO parseSelectStatement(SQLSelectStatement selectStatement) {
		SqlStatementVO sqlStatementVO = new SqlStatementVO();
		return sqlStatementVO;
	}
	/**
	 * 解析delete sql语句
	 * @param deleteStatement
	 * @return
	 */
	private static SqlStatementVO parseDeleteStatement(SQLDeleteStatement deleteStatement) {
		List<WhereConditionVO> list = new ArrayList<WhereConditionVO>();
		SqlStatementVO vo = new SqlStatementVO();
		SQLExprTableSource exprTableSource = (SQLExprTableSource) deleteStatement.getTableSource();
		String databaseName = "";
		String tableName = "";
		SQLExpr expr = exprTableSource.getExpr();
		if(expr instanceof SQLPropertyExpr){
			databaseName = ((SQLPropertyExpr) expr).getOwner().toString();
			tableName = ((SQLPropertyExpr) expr).getName();
		}else{
			tableName = expr.toString();
		}
		if(deleteStatement.getWhere()!=null){
			list = parseWhereConditionInfo(deleteStatement.getWhere());
		}
		vo.setDatabaseName(databaseName);
		vo.setTableName(tableName);
		vo.setWhereCondition(list);
		vo.setTableName(tableName);
		return vo;
	}
	/**
	 * 解析 update sql语句
	 * @param updateStatement
	 * @return
	 */
	private static SqlStatementVO parseUpdateStatement(SQLUpdateStatement updateStatement) {
		List<WhereConditionVO> whereConditionList = new ArrayList<WhereConditionVO>();
		SqlStatementVO vo = new SqlStatementVO();
		Map<String, Object> updateItemsMap = new HashMap<String, Object>();
		List<SQLUpdateSetItem> list = updateStatement.getItems();
		if(!list.isEmpty()&&list.size()==1){
			for (SQLUpdateSetItem sqlUpdateSetItem : list) {
				SQLExpr columnExpr = sqlUpdateSetItem.getColumn();
				SQLExpr valueExpr = sqlUpdateSetItem.getValue();
				if(columnExpr instanceof SQLIdentifierExpr){
					String column = ((SQLIdentifierExpr) columnExpr).getName();
					if(valueExpr instanceof SQLCharExpr){
						Object value = 	((SQLCharExpr) valueExpr).getValue();
						updateItemsMap.put(column, value);
					}
					
				}else if(columnExpr instanceof SQLListExpr){
					List<SQLExpr> columnList = ((SQLListExpr) columnExpr).getItems();
					List<SQLExpr> valueList = ((SQLListExpr) valueExpr).getItems();
					for(int i=0;i<columnList.size();i++){
						updateItemsMap.put(columnList.get(i).toString(), valueList.get(i).toString());
					}
				}
				
				
				/*SQLListExpr columnExpr = (SQLListExpr) sqlUpdateSetItem.getColumn();
				SQLListExpr valueExpr = (SQLListExpr) sqlUpdateSetItem.getValue();
				List<SQLExpr> columnList = columnExpr.getItems();
				List<SQLExpr> valueList = valueExpr.getItems();
				for(int i=0;i<columnList.size();i++){
					updateItemsMap.put(columnList.get(i).toString(), valueList.get(i).toString());
				}*/
			}
		}else{
			for (SQLUpdateSetItem sqlUpdateSetItem : list) {
				String column = sqlUpdateSetItem.getColumn().toString();
				String value = sqlUpdateSetItem.getValue().toString();
				updateItemsMap.put(column, value);
			}
		}
		if(updateStatement.getWhere()!=null){
			whereConditionList = parseWhereConditionInfo(updateStatement.getWhere());
		}
		SQLExprTableSource exprTableSource = (SQLExprTableSource) updateStatement.getTableSource();
		String databaseName = "";
		String tableName = "";
		SQLExpr expr = exprTableSource.getExpr();
		if(expr instanceof SQLPropertyExpr){
			databaseName = ((SQLPropertyExpr) expr).getOwner().toString();
			tableName = ((SQLPropertyExpr) expr).getName();
		}else{
			tableName = expr.toString();
		}
		vo.setDatabaseName(databaseName);
		vo.setWhereCondition(whereConditionList);
		vo.setTableName(tableName);
		vo.setUpdateItemsMap(updateItemsMap);
		return vo;
	}
	/**
	 * 解析insert语句信息
	 * @param insertStatement
	 * @return
	 */
	private static SqlStatementVO parseInsertStatement(SQLInsertStatement insertStatement) {
		SqlStatementVO vo = new SqlStatementVO();
		Map<String, Object> insertItemsMap = new HashMap<String, Object>();
		List<String> columnList = new ArrayList<String>();
		//List<String> valueList = new ArrayList<String>();
		List<Object> valueList = new ArrayList<Object>();
		List<SQLExpr> columns = insertStatement.getColumns();
		for (SQLExpr sqlExpr : columns) {
			columnList.add(sqlExpr.toString());
		}
		List<ValuesClause> vaList = insertStatement.getValuesList();
		if(!vaList.isEmpty()&&vaList.size()>0){
			if(vaList.size()>1){
				for (ValuesClause valuesClause : vaList) {
					List<SQLExpr> valuesList = valuesClause.getValues();
					List<String> tempList = new ArrayList<String>();
					for (SQLExpr sqlExpr : valuesList) {
						tempList.add(sqlExpr.toString());
					}
					valueList.add(tempList);
					
				}
			}else{
				List<SQLExpr> exprs = vaList.get(0).getValues();
				for (SQLExpr sqlExpr : exprs) {
					valueList.add(sqlExpr.toString());
				}
			}
		}
		SQLExprTableSource exprTableSource = (SQLExprTableSource) insertStatement.getTableSource();
		String databaseName = "";
		String tableName = "";
		SQLExpr expr = exprTableSource.getExpr();
		if(expr instanceof SQLPropertyExpr){
			databaseName = ((SQLPropertyExpr) expr).getOwner().toString();
			tableName = ((SQLPropertyExpr) expr).getName();
		}else{
			tableName = expr.toString();
		}
		vo.setDatabaseName(databaseName);
		insertItemsMap.put("columns", columnList);
		insertItemsMap.put("values", valueList);
		vo.setTableName(tableName);
		vo.setInsertItemsMap(insertItemsMap);
		return vo;
	}
	/**
	 * 解析where条件信息
	 * 
	 * @param where :where对象
	 * @return where条件的list
	 */
	private static List<WhereConditionVO> parseWhereConditionInfo(SQLExpr where) {
		List<WhereConditionVO> list = new ArrayList<WhereConditionVO>();
		SQLBinaryOpExpr binaryOpExpr = (SQLBinaryOpExpr) where;
		SQLExpr left = binaryOpExpr.getLeft();
		if(left instanceof SQLIdentifierExpr){
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(binaryOpExpr.getLeft().toString());
			conditionVO.setOperator(binaryOpExpr.getOperator().toString());
			conditionVO.setValue(binaryOpExpr.getRight().toString());
			list.add(conditionVO);
		}
		if(left instanceof SQLBinaryOpExpr){
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLBinaryOpExpr) left).getLeft().toString());
			conditionVO.setOperator(((SQLBinaryOpExpr) left).getOperator().toString());
			conditionVO.setValue(((SQLBinaryOpExpr) left).getRight().toString());
			list.add(conditionVO);
		}
		if(left instanceof SQLBetweenExpr){
			StringBuilder sb = new StringBuilder();
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLBetweenExpr) left).getTestExpr().toString());
			conditionVO.setOperator(Const.SQL_OPERATOR_BETWEEN);
			conditionVO.setValue(sb.append(((SQLBetweenExpr) left).getBeginExpr().toString()).append(",").append(((SQLBetweenExpr) left).getEndExpr().toString()).toString());
			list.add(conditionVO);
		}
		if(left instanceof SQLInListExpr){
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLInListExpr) left).getExpr().toString());
			conditionVO.setOperator(Const.SQL_OPERATOR_IN);
			conditionVO.setValue(StringUtils.join(((SQLInListExpr) left).getTargetList().toArray(),","));
			list.add(conditionVO);
		}
		if (left instanceof SQLPropertyExpr){
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLPropertyExpr) left).getName());
			conditionVO.setOperator(binaryOpExpr.getOperator().toString());
			conditionVO.setValue(binaryOpExpr.getRight().toString());
			list.add(conditionVO);
		}
		SQLExpr right = binaryOpExpr.getRight();
		if(right instanceof SQLBinaryOpExpr){
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLBinaryOpExpr) right).getLeft().toString());
			conditionVO.setOperator(((SQLBinaryOpExpr) right).getOperator().toString());
			conditionVO.setValue(((SQLBinaryOpExpr) right).getRight().toString());
			list.add(conditionVO);
		}
		if(right instanceof SQLBetweenExpr){
			StringBuilder sb = new StringBuilder();
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLBetweenExpr) right).getTestExpr().toString());
			conditionVO.setOperator(Const.SQL_OPERATOR_BETWEEN);
			conditionVO.setValue(sb.append(((SQLBetweenExpr) right).getBeginExpr().toString()).append(",").append(((SQLBetweenExpr) right).getEndExpr().toString()).toString());
			list.add(conditionVO);
		}
		if(right instanceof SQLInListExpr){
			WhereConditionVO conditionVO = new WhereConditionVO();
			conditionVO.setKey(((SQLInListExpr) right).getExpr().toString());
			conditionVO.setOperator(Const.SQL_OPERATOR_IN);
			conditionVO.setValue(StringUtils.join(((SQLInListExpr) right).getTargetList().toArray(),","));
			list.add(conditionVO);
		}
		return list;
	}

}
