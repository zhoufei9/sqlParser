package com.gosun.mmtrix.sqlParser.constants;

import java.util.Arrays;
import java.util.List;

public interface Const {
	
	String DB_MYSQL = "mysql";
	
	String DB_ORACLE = "oracle";
	
	String DB_DB2 = "db2";
	
	String OPR_INSERT = "INSERT";
	
	String OPR_UPDATE = "UPDATE";
	
	String OPR_DELETE = "DELETE";
	
	String OPR_SELECT = "SELECT";
	
	Integer SUCCESS_CODE = 0;
	
	Integer ERROR_CODE = 1000;
	
	String SQL_OPERATOR_BETWEEN = "BetweenAnd";
	
	String SQL_OPERATOR_IN = "In";
	
	String EXCEPTION_ILLEAGL_ARGS_MSG = "Illegal args:";
	
	String EXCEPTION_UNKNOW_ERROR_MSG = "Unkonw Error:";
	
	String EXCEPTION_ILLEGAL_DATABASETYPE_MSG = "Illegal DatabaseType:";
	
	String EXCEPTION_ILLEGAL_SQL_MSG = "Illegal SQL:";
	
	List<String> SQL_LIST = Arrays.asList("select count(*) from TEST.EMPLOEE where id in (00001,00002,00003,00004);",
			"update tbl_person t set name = 'mmtrix',age = 25 ,email = '764182087@qq.com' where id = '1001' and sex = 'M'",
			"insert into tbl_person  (id,name,age) values ('1001','mmtrix',24);",
			"delete from tbl_person where id = '1001' and name = 'mmtrix';");
	
	List<String> DATABASE_TYPE = Arrays.asList("mysql","oracle","db2");

}
