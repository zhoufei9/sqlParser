package com.gosun.mmtrix.sqlParser.vo;

import java.io.Serializable;
import java.util.List;

public class ParamInfo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String dbType;
	
	private List<String> sqlList;

	public String getDbType() {
		return dbType;
	}

	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	public List<String> getSqlList() {
		return sqlList;
	}

	public void setSqlList(List<String> sqlList) {
		this.sqlList = sqlList;
	}
	
	

}
