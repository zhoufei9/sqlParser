package com.gosun.mmtrix.sqlParser.test;


import org.junit.Test;

import com.gosun.mmtrix.sqlParser.util.JsonUtil;
import com.gosun.mmtrix.sqlParser.util.SqlParserUtil;
import com.gosun.mmtrix.sqlParser.vo.JsonResult;




public class TestSqlParser {
	
	@Test
	public void testMysqlInsert(){
		//String sql = "insert into tbl_person (id,name,age) values ('1001','mmtrix',24)";
		//String sql = "insert user(id,name) values(1,'1')";
		//String sql = "insert into user(id,name) select id,1 where id =1";
		//String sql = "insert into tbl_person   values ('1001','mmtrix',24)";
		String sql = "insert into tbl_person  (id,name,age) values ('1001','mmtrix',24),('1002','test',22),('1003','gosun',25)";
		String dbType = "mysql";
		JsonResult jsonResult = SqlParserUtil.parseSqlParser(dbType,sql);
		String str = JsonUtil.object2JsonString(jsonResult);
		System.out.println(str);
	}
	@Test
	public void testMysqlUpdate(){
		String sql = "update tbl_person t set name = 'he_jiebing',age = 25 where id = '1001' and sex = 'M'";
		String dbType = "mysql";
		JsonResult jsonResult = SqlParserUtil.parseSqlParser(dbType,sql);
		String str = JsonUtil.object2JsonString(jsonResult);
		System.out.println(str);
	}
	@Test
	public void testMysqlDelete(){
		String sql = "delete from tbl_person where id = '1001' and name = 'he_jiebing'";
		//String sql = "delete from tbl_person where id = '1001'";
		String dbType = "mysql";
		JsonResult jsonResult = SqlParserUtil.parseSqlParser(dbType,sql);
		String str = JsonUtil.object2JsonString(jsonResult);
		System.out.println(str);
	}
	@Test
	public void testDB2Insert(){
		//String sql = "insert into tbl_person  (id,name,age) values ('1001','mmtrix',24)";
		String sql = "insert user(id,name) values(1,'1')";
		String dbType = "db2";
		JsonResult jsonResult = SqlParserUtil.parseSqlParser(dbType,sql);
		String str = JsonUtil.object2JsonString(jsonResult);
		System.out.println(str);
	}
	@Test
	public void testDB2Update(){
		//String sql = "update tbl_person t set name = 'he_jiebing',age = 25 ,email = '764182087@qq.com' where id = '1001' and sex = 'M'";
		//String sql = "update tbl_person t set (name,age,email) = ('hejiebing','25','764182087@qq.com') where id = '1001' and sex = 'M'";
		String sql = "update tbl_person t set (name,age,email) = ('hejiebing','25','764182087@qq.com')";
		String dbType = "db2";
		JsonResult jsonResult = SqlParserUtil.parseSqlParser(dbType,sql);
		String str = JsonUtil.object2JsonString(jsonResult);
		System.out.println(str);
	}
	@Test
	public void testDB2Delete(){
		//String sql = "delete from tbl_person where id = '1001'";//情况一
		//String sql = "delete from tbl_person where id = '1001' and name = 'mmtrix'";//情况二
		//String sql = "delete from tbl_person where id between '1001' and '1003' and name = 'mmtrix'";//情况三
		//String sql = "delete from tbl_person where id in ('1001','1002','1003' ) and name = 'mmtrix'";//情况四
		//String sql = "delete from tbl_person where id > '1001' and name = 'he_jiebing'";//情况五
		//String sql = "delete from tbl_person where id = (select id from tbl_person2 where name = 'mmtrix')";//情况六
		//String sql = "delete from tbl_person";//情况六
		//String sql = "delete from tbl_person where tbl_person.id = '1001'";
		String sql = "delete from test.tbl_person where tbl_person.id = '1001'";
		String dbType = "db2";
		JsonResult jsonResult = SqlParserUtil.parseSqlParser(dbType,sql);
		String str = JsonUtil.object2JsonString(jsonResult);
		System.out.println(str);
	}
	
	
	

}
